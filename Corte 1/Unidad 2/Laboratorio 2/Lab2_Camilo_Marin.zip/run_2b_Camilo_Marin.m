close all
clear all
clc
fun = @(x) tan(x)^2-x
iter = 20;
raiz = my_bisection_function_Camilo_Marin(fun,iter)
fprintf("Raiz=: "+string(raiz))