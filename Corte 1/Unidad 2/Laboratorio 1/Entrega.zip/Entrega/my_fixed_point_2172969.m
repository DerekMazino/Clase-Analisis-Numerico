fun = @(x) 501.0625-201.0625*exp(-0.4*x)
a = 0;
b = 100;
po = 5;
Iter = 3;
my_fixed_point(fun,a,b,po,Iter);
P = visual_verification_2172969(fun,a,b);
% function x = my_fixed_point(fun,a,b,po,Iter)    
%     for i=1:Iter
%         fprintf('p'+string(i)+'= 1/p'+string(i-1)+' = '+string(fun(po)))
%         po=fun(po)
%     end
%     fprintf('Punto fijo en: '+string(po))
% end